package com.pme.reservations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
