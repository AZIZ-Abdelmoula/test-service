package com.pme.reservations.controlleurs;
import com.pme.reservations.dto.ReservationRequest;
import com.pme.reservations.entities.Salle;
import com.pme.reservations.services.ReservationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reservation")
public class SalleController {

    @Autowired
    private ReservationService reservationService;

    @PostMapping("/")
    public ResponseEntity<Salle> reserverSalle(@RequestBody  ReservationRequest input) {
        Salle salle = reservationService.reserverSalle(input.getCreneauHoraire(), input.getTypeReunionDto().name(), input.getNombrePersonnes());
        if (salle != null) {
            return ResponseEntity.ok(salle);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}