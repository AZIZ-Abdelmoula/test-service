package com.pme.reservations.services;

import com.pme.reservations.Mappers.CreneauMapper;
import com.pme.reservations.entities.Salle;
import com.pme.reservations.models.Creneau;
import com.pme.reservations.repositories.ReservationRepository;
import com.pme.reservations.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ReservationService {

    @Autowired
    private SalleRepository salleRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Value("${param.cleaning.time}")
    int cleaningTime;
    @Value("${param.capacite.salle}")
    float capaciteMax;

    public Salle reserverSalle(String creneau, String typeReunion, int nombrePersonnes) {
        // Etape 1 : Récupérer toutes les salles disponibles

         Iterable<Salle> sallesDisponibles = salleRepository.findAll();
        //        List<Salle>  sallesDisponibles = salleRepository.findSallesByCapaciteMaxIsGreaterThan(nombrePersonnes/capaciteMax);
        Salle salleAdaptee = null;

        for (Salle salle : sallesDisponibles) {
            //Etape 1 : Je Vérifie si la salle a la capacité suffisante sinn je passe à la salle suivante
            //On peut creer une requete pour récuperer que les slles ayants la capacité suffisante
            if (salle.getCapaciteMax() * capaciteMax < nombrePersonnes) {
                continue;
            }

            // Etape 2 : Je Vérifie si la salle a les équipements nécessaires
            if (!hasRequiredEquipments(salle, typeReunion)) {
                continue;
            }

            // Etape 3  : Je Vérifie sila salle est libre pour le créneau choisi
            if (!isSalleAvailable(salle, creneau)) {
                continue;
            }

            // Vérifier le temps tampon pour le nettoyage
            if (!isCleaningTimeAvailable(salle, creneau)) {
                continue;
            }

            // Si tous les critères sont remplis, réserver la salle
            salleAdaptee = salle;
            break;
        }

        return salleAdaptee;
    }

    private boolean hasRequiredEquipments(Salle salle, String typeReunion) {

        return false;
    }

    private boolean isSalleAvailable(Salle salle, String creneau) {
        Creneau c= CreneauMapper.mapToCreneau(creneau);
        return (reservationRepository.countBySalleNomAndAndStartTimeAndEndTime(salle.getNom(),c.getStartTime(),c.getEndTime())!=0);
    }

    private boolean isCleaningTimeAvailable(Salle salle, String creneau) {
        Creneau c= CreneauMapper.mapToCreneau(creneau);
        return (reservationRepository.countBySalleNomAndAndStartTimeAndEndTime(salle.getNom(),c.getStartTime()-cleaningTime,c.getEndTime()-cleaningTime)!=0);
    }
}