package com.pme.reservations.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class Equipement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;
    @ManyToMany(mappedBy = "equipements")  // Cette relation est définie côté 'Salle'
    private List<Salle> salles;
    @ManyToMany
    private List<TypeReunion> typesReunion;
}
