package com.pme.reservations.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ReservationRequest {
    @NotNull(message = "Le créneau horaire est requis.")
    @Size(min = 5, max = 11, message = "Le créneau horaire doit avoir une longueur valide : Ex 8h00-9h00 ")
    private String creneauHoraire;

    @NotNull(message = "Le type de réunion est requis.")
    private TypeReunionDto typeReunionDto;

    @Positive(message = "Le nombre de personnes doit être positif.")
    private int nombrePersonnes;

}
